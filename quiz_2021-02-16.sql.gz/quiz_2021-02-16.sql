# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 0.0.0.0 (MySQL 5.7.33)
# Database: quiz
# Generation Time: 2021-02-17 02:33:11 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table fbla_quiz
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fbla_quiz`;

CREATE TABLE `fbla_quiz` (
  `chooseQ` int(11) NOT NULL,
  `questionType` int(11) NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `choiceOne` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `choiceTwo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `choiceThree` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `choiceFour` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `correctAnswer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `userAnswer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `qScore` int(11) NOT NULL,
  PRIMARY KEY (`chooseQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `fbla_quiz` WRITE;
/*!40000 ALTER TABLE `fbla_quiz` DISABLE KEYS */;

INSERT INTO `fbla_quiz` (`chooseQ`, `questionType`, `question`, `choiceOne`, `choiceTwo`, `choiceThree`, `choiceFour`, `correctAnswer`, `userAnswer`, `qScore`)
VALUES
	(0,0,'What are the official colors of FBLA?*','a) Green and Blue','b) Black and Blue','c) Gold and Blue','d) Red and Blue','c) Gold and Blue','empty',0),
	(1,0,'Who was the first executive director of FBLA-PBL?*','a) Barbara Small','b) Dr. Edward Miller','c) Lisa Frye Smothers','d) Richard Bowen','b) Dr. Edward Miller','empty',0),
	(2,0,'Which officer presides over and conducts meetings according to Parliamentary Procedure?*','a) President','b) Vice President','c) Secretary','d) Treasurer','a) President','empty',0),
	(3,0,'How many goals does FBLA-PBL have?*','a) 6','b) 7','c) 8','d) 9','d) 9','empty',0),
	(4,0,'In what year was FBLA-PBL officially sponsored by the National Council for Business Education (NBEA)?*','a) 1940','b) 1942','c) 1944','d) 1946','a) 1940','empty',0),
	(5,0,'How many votes would a chapter of 99 members have at the National Leadership Conference?*','a) 1','b) 2','c) 3','d) 4','c) 3','empty',0),
	(6,0,'Proposed amendments to the National Bylaws must be submitted by which date?*','a) January 1st','b) February 1st','c) March 1st','d) April 1st','d) April 1st','empty',0),
	(7,0,'If business of the National Executive Council is conducted by mail, what is the vote required for action?*','a) Unanimous ','b) 3/4','c) 2/3','d) 3/5','b) 3/4','empty',0),
	(8,0,'Which month is National Education for Business month?*','a) September','b) October','c) November','d) December','c) November','empty',0),
	(9,0,'What year did FBLA gain independent status?*','a) 1969','b) 1970','c) 1971','d) 1972','a) 1969','empty',0),
	(10,1,'What do the initials USDE stand for?*','n/a','n/a','n/a','n/a','United States Department of Education','empty',0),
	(11,1,'What symbol on the FBLA emblem denotes its belief in democracy, liberty, and the American way of life?*','n/a','n/a','n/a','n/a','Eagle','empty',0),
	(12,1,'What is the national program called that encourages chapters from all divisions to team up to leverage their potential for success?*','n/a','n/a','n/a','n/a','Connecting Chapters','empty',0),
	(13,1,'What is another name for a written plan of action? (Do not add an article at the beginning)*','n/a','n/a','n/a','n/a','Program of Work','empty',0),
	(14,1,'What is the national publication for FBLA and FBLA-Middle level advisers called?*','n/a','n/a','n/a','n/a','Hotline','empty',0),
	(15,1,'What color of candle symbolizes the office of president?*','n/a','n/a','n/a','n/a','Red','empty',0),
	(16,1,'Where was the first State Chapter located?*','n/a','n/a','n/a','n/a','Iowa','d',0),
	(17,1,'What two words are repeated throughout the FBLA-PBL creed?*','n/a','n/a','n/a','n/a','I Believe','I Believe',0),
	(18,1,'What national recognition award goes to the local chapter \nthat has the largest chapter member based on the percentage of school enrollment?*','n/a','n/a','n/a','n/a','Market Share Award','empty',0),
	(19,1,'What does FBLA stand for?*','n/a','n/a','n/a','n/a','Future Business Leaders of America','empty',0),
	(20,2,'The dress code of FBLA activities is Business or Professional attire.*','True','False','n/a','n/a','True','empty',0),
	(21,2,'FBLA only focuses on Business.*','True','False','n/a','n/a','False','False',1),
	(22,2,'FBLA is still an active club during the 2020-2021 Pandemic.*','True','False','n/a','n/a','True','True',1),
	(23,2,'The keywords for the FBLA code of ethics are I believe\".*\"','True','False','n/a','n/a','False','empty',0),
	(24,2,'FBLA is sponsored by Rachael Aufman and Scott Larson.*','True','False','n/a','n/a','True','empty',0),
	(25,2,'The FBLA Middle Level membership is open to students in only grades 6-8.*','True','False','n/a','n/a','False','b',0),
	(26,2,'FBLA started out as a collegiate organization.*','True','False','n/a','n/a','True','Eagle',0),
	(27,2,'The concept of FBLA was developed at Rider College.*','True','False','n/a','n/a','False','False',1),
	(28,2,'The Alumni Division was founded by James Price in 1979.*','True','False','n/a','n/a','True','True',1),
	(29,2,'The current FBLA National President is Greg Erikhman.*','True','False','n/a','n/a','False','empty',0),
	(30,3,'What charitable organization does FBLA primarily support?*','Gift of Life (ARORA)','Regional Summits','March of Dimes','The Spotlight','March of Dimes','c',0),
	(31,3,'When is National Community Service Day?*','January 6th','February 15th','November 15th','November 17th','February 15','a',0),
	(32,3,'In what year was the professional division created?*','1980','1983','1986','1989','1989','empty',0),
	(33,3,'How is FBLA-PBL, Inc. primarily funded?*','Membership Dues','Sponsors','Donations','Fundraisers','Membership Dues','empty',0),
	(34,3,'The National Center\'s Conference Room was a gift from what state?*','Mississippi','Arkansas','Georgia','Florida','Arkansas','c',0),
	(35,3,'Chapter activities fall into five functional areas. Which of these is NOT one of them?*','Professional Developmet','Technology','Social','Service','Technology','',0),
	(36,3,'Which of these is the individual recognition award where members must complete 10 of 16 activities from four different sections of the entry form?*','Enterprise-Level Award','Membership Achievement Award','Market Share Award','Business Level Award','Enterprise-Level Award','empty',0),
	(37,3,'Who is the Gold Seal Award of Merit named after?*','Sam Kessler','Dorothy L. Travis','Hollis and Kitty Guy','Otis Spunkmeyer','Hollis and Kitty Guy','empty',0),
	(38,3,'Which of these is NOT on the FBLA and PBL emblems?*','Education','Growth','Progress','Service','Growth','Education',0),
	(39,3,'What is the minimum number of members required to start a new/reactivate a chapter in FBLA-ML?*','One','Two','Three','Four','Three','empty',0),
	(40,0,'In which month is FBLA-PBL week held?*','a) February','b) April','c) June','d) August','a) February','d) August',0),
	(41,0,'What is FBLA\'s 2020-2021 theme?*','a) Growth','b) Perseverance','c) Loyalty','d) Aspire','d) Aspire','empty',0),
	(42,0,'Which of these is not part of a goal of FBLA?*','a) Strengthen student confidence','b) Create interest in and understanding of American business enterprise','c) Facilitate the transition from an adolescent mindset to an adult one','d) Develop character','c) Facilitate the transition from an adolescent mindset to an adult one','a) Strengthen student confidence',0),
	(43,0,'There are 4 types of members. Which of these is NOT one of them?*','a) Active Members','b) Alumni Members','c) Professional Members','d) Honorary Life Members','b) Alumni Members','empty',0),
	(44,0,'Which of these states is NOT in the Eastern Region?*','a) North Carolina','b) Vermont','c) Delaware','d) Connecticut','a) North Carolina','c) Delaware',0),
	(45,0,'Which of these states is NOT in the Southern Region?*','a) Louisiana','b) Florida','c) Virginia','d) Kansas','d) Kansas','empty',0),
	(46,0,'Which of these states is NOT in the Western Region?*','a) Hawaii','b) Nevada','c) Oklahoma','d) Montana','c) Oklahoma','empty',0),
	(47,0,'Which of these states is NOT in the North Central Region?*','a) Minnesota','b) South Dakota','c) Iowa','d) Ohio','b) South Dakota','c) Iowa',0),
	(48,0,'Which of these companies does NOT sponsor FBLA?*','a) Suntrust','b) Amazon','c) Visa','d) Chase','d) Chase','d) Chase',1),
	(49,0,'Which of these statements is repeated in the FBLA Code of Ethics?*','a) I Believe','b) I Will','c) I Can','d) I Strive','b) I Will','empty',0);

/*!40000 ALTER TABLE `fbla_quiz` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
